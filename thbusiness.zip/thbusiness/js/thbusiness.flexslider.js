jQuery(window).load(function() {
  jQuery('.flexslider').flexslider({
    animation: "slide",
    direction: "horizontal",
	slideshowSpeed: 7000,
	animationSpeed: 600
  });
});