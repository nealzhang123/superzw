<?php
/**
 * The Sidebar containing the footer mid widget area.
 *
 * @package thbusiness
 */
?>
	<div id="secondary" class="widget-area" role="complementary">
		<?php if ( ! dynamic_sidebar( 'footer-mid' ) ) : ?>


		<?php endif; // end sidebar widget area ?>
	</div><!-- #secondary -->
