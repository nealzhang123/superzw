<?php
/**
 * The Sidebar containing the footer right widget area.
 *
 * @package thbusiness
 */
?>
	<div id="secondary" class="widget-area" role="complementary">
		<?php if ( ! dynamic_sidebar( 'footer-right' ) ) : ?>


		<?php endif; // end sidebar widget area ?>
	</div><!-- #secondary -->
