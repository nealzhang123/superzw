<?php
/**
 * Template Name: 联系我们模板
 *
 * Displays the Test Template of the theme.
 *
 * @package thbusiness
 */
get_header(); ?>
<div class="col-xs-12 col-sm-12 col-md-12">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			联系我们模板,整理中...
		</main><!-- #main -->
	</div><!-- #primary -->

</div><!-- .col-xs-12 col-sm-12 col-md-12 -->
<?php get_footer(); ?>